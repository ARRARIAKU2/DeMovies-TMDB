export const apiKey = "1487e6da2b780246708f52464d6d0f05";
export const baseURL = "https://api.themoviedb.org/3";
export const imageURL = "https://image.tmdb.org/t/p/w500";