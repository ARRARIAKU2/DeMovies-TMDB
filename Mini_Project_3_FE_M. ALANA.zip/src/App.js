import logo from './logo.svg';
import Router from './routes/Router';
import './App.css';

function App() {
  return (
    <>
      <Router />
    </>
  );
}

export default App;
